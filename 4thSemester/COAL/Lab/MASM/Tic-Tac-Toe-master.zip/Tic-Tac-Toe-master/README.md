# Tic-Tac-Toe
Tic - Tac - Toe game implemented in assembly (8086)

- You need a 8086 emulator to run this game.
- It is a 2 player game. Player 1 will place 'X' mark and Player 2 will place 'O' mark.
- Has option to repeat the game after it is over.
- Character inputs will be checked, if you enter any invalid character, it will prompt to input again.
- If you try to set mark to a cell already marked, it will prompt to input again. <br> <br>



![untitled-1](https://user-images.githubusercontent.com/14056189/44297499-4cdbe700-a2f4-11e8-89fe-8a0028b8d03d.jpg)
<br>
#### Game Screenshot<br>
![game_ss](https://user-images.githubusercontent.com/14056189/111333263-baaf4180-869c-11eb-876e-107e3eed3019.jpg)
